#include "advice_from_kyra.h"
#include "fitfriend.h"
#include "ui_fitfriend.h"
#include <QLabel>
#include <QHBoxLayout>


advice_from_kyra::advice_from_kyra(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::FitFriend)

{
    ui->setupUi(this);

    QHBoxLayout* layout= new QHBoxLayout;

       QWidget* wid= new QWidget;
    QLabel* intro_label = new QLabel("Coming soon");
    layout->addWidget(intro_label);

    QPixmap pic_of_kyra(":/Kyra");
    QLabel* pic_label= new QLabel;

    pic_label->setPixmap(pic_of_kyra);
    layout->addWidget(pic_label);
    pic_label->setScaledContents(true);
    pic_label->setFixedSize(300, 400);



    wid->setLayout(layout);
    this->setCentralWidget(wid);
    this->show();

}








advice_from_kyra::~advice_from_kyra()
{
    delete ui;
}
